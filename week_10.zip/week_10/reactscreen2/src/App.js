import './App.css';
import Pharmacy from './Pharmacy';
 
function App() {
  return (
    <div>
      <Pharmacy/>
    </div>
  );
}
 
export default App;
